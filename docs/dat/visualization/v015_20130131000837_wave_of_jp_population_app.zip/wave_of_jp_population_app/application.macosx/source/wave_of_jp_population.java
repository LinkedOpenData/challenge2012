import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class wave_of_jp_population extends PApplet {

int winX = 1200;
int winY =  600;
int plotX1 = 90; 
int plotX2 = winX - 70;
int plotY1 = 60;
int plotY2 = winY - 70;

FloatTable data;
float dataMin, dataMax;

int rowCount;
int currentRow = 0;
int columnCount;
int currentColumn = 0;

int yearMin, yearMax;
int[] years;
int yearInterval = 50;
float barWidth;

int volumeInterval = 1000000;
int volumeIntervalMinor = 500000;

float[] tabLeft, tabRight;
float tabTop, tabBottom;
float tabPad = 10;

Integrator[] interpolators;

PFont plotFont; 

FloatTable birthData;
float birthDataMin, birthDataMax;
int birthRowCount;
int birthCurrentRow = 0;
int birthColumnCount;
int birthCurrentColumn = 0;

FloatTable laborData;
float laborDataMin, laborDataMax;
int laborRowCount;
int laborCurrentRow = 0;
int laborColumnCount;
int laborCurrentColumn = 0;

FloatTable marriageData;
float marriageDataMin, marriageDataMax;
int marriageRowCount;
int marriageCurrentRow = 0;
int marriageColumnCount;
int marriageCurrentColumn = 0;

public void setup() {
  
  size(winX, winY);
  
  data = new FloatTable("japan-population.tsv");
//  rowCount = data.getRowCount();
  rowCount = 23;  //\u30c7\u30fc\u30bf\u8868\u793a\u30922030\u5e74\u307e\u3067\u306b\u9650\u5b9a
  columnCount = data.getColumnCount();

  years = PApplet.parseInt(data.getRowNames());
  yearMin = years[0]-90;
//  yearMax = years[years.length-1];  
  yearMax = 2030;  
  barWidth = ((plotX2-plotX1)/(yearMax-yearMin)*5)*0.85f; 
  
  dataMin = 0;
  dataMax = ceil(data.getTableMax() / volumeInterval) * volumeInterval;

  interpolators = new Integrator[rowCount];
  for (int row = 0; row < rowCount; row++) {
    float initialValue = data.getFloat(row, 0);
    interpolators[row] = new Integrator(initialValue);
    interpolators[row].attraction = 0.1f;  // Set lower than the default
  }

  laborData = new FloatTable("labor.tsv");
  laborRowCount = laborData.getRowCount();
  laborColumnCount = laborData.getColumnCount();

  marriageData = new FloatTable("marriage.tsv");
  marriageRowCount = marriageData.getRowCount();
  marriageColumnCount = marriageData.getColumnCount();

  birthData = new FloatTable("livebirths.tsv");
  birthRowCount = birthData.getRowCount();
  birthColumnCount = birthData.getColumnCount();
  
  plotFont = createFont("SansSerif", 20);
  textFont(plotFont,20);

  smooth();
}


public void draw() {
  background(224);
  
  // Show the plot area as a white box  
  fill(255);
  rectMode(CORNERS);
  noStroke();
  rect(plotX1, plotY1, plotX2, plotY2);

  drawAxisLabelsJP();
  drawVolumeLabels();
  drawYearLabels();
  drawLegend();

  for (int row = 0; row < rowCount; row++) {
    interpolators[row].update();
  }
  noStroke();
  drawDataBars(currentRow);
  drawBirthDataBars(currentRow);
  drawMarriageDataBars(currentRow);
  drawLaborDataBars(currentRow);

}



public void keyPressed()
{
  // if the key is between 'A'(65) and 'z'(122)
  if(key == '[' || key==',' || keyCode==LEFT) {
    if(currentRow >= 1){currentRow--;}
  } else if(key==']' || key=='.' || keyCode==RIGHT) {
    if(currentRow < rowCount-1){currentRow++;}
  }
}

public void mouseMoved() {
//  if (mouseY > tabTop && mouseY < tabBottom) {
//    for (int row = 0; row < rowCount; row++) {
//      if (mouseX > tabLeft[row] && mouseX < tabRight[row]) {
//        setCurrent(row);
//      }
//    }
//  }
}

public void mousePressed() {
//  float barWidth = ((plotX2-plotX1)/(yearMax-yearMin)*5); 
//  if (mouseY > plotY1 && mouseY < plotY2) {
//    for (int row = 0; row < rowCount; row++) {
//      if (mouseX > tabLeft[row]-barWidth && mouseX < tabRight[row]-barWidth) {
//        fill(0);
//        textAlign(CENTER);
//        text("aaa", mouseX, mouseY);
//      }
//    }
//  }
}



public void setCurrent(int row) {
  currentRow = row;
  for (int col = 0; col < columnCount; col++) {
    interpolators[row].target(data.getFloat(row, col));
  }
}


public void drawAxisLabelsJP() {
  fill(0);
  textLeading(15);

  textSize(14);
  textAlign(RIGHT, BOTTOM);
  text("\u4eba\u53e3(\u4e07\u4eba)", plotX1, plotY1-15);
  textAlign(CENTER, TOP);
  text("\u7523\u307e\u308c\u305f\u5e74", plotX1-20, tabBottom-10);
  textSize(12);
//  text("\uff08\u5927\u6587\u5b57\u306f\u8abf\u67fb\u5e74\uff09", plotX1-20, tabBottom+5);

  textSize(18);
  textAlign(CENTER, BOTTOM);
  text("\u4eba\u53e3\u306e\u6ce2 (1920\u5e74-2030\u5e74)", width/2, plotY1-25);
  textSize(12);
  textAlign(CENTER, BOTTOM);
  text("\u5de6\u53f3\u306e\u77e2\u5370\u30ad\u30fc\uff08\u300c\u2190\u300d\u300c\u2192\u300d\uff09\u3067\u3001\u8868\u793a\u3055\u308c\u308b\u8abf\u67fb\u5e74\u304c\u5909\u308f\u308a\u307e\u3059\u3002", width/2, plotY1-5);
}

public void drawAxisLabels() {
  fill(0);
  textLeading(15);

  textSize(12);
  textAlign(RIGHT, BOTTOM);
  text("population(m)", plotX1, plotY1-15);
  textAlign(CENTER, TOP);
  text("year of birth", plotX1-20, tabBottom-10);
  textSize(10);
  text("(year of research)", plotX1-20, tabBottom+5);

  textSize(18);
  textAlign(CENTER, BOTTOM);
  text("Japan population by birth 5 year", width/2, plotY1-25);
  textSize(12);
  textAlign(CENTER, BOTTOM);
  text("1920 - 2010", width/2, plotY1-5);
}

public void drawLegend(){
  rectMode(CORNERS);
  noStroke();
  textAlign(LEFT,TOP);

  int legendX = plotX2-240;  
  int legendY = plotY1+20;
  int legendWidth = 220;
  int legendHeight = 24;

  colorMode(HSB,360,100,100);
  fill(60,30,100);
  rect(legendX, legendY-2, legendX+legendWidth, legendY+16);
  fill(245,30,100);
  rect(legendX, legendY-2+legendHeight, legendX+legendWidth, legendY+16+legendHeight);
  fill(135,30,100);
  rect(legendX, legendY-2+(legendHeight*2), legendX+legendWidth, legendY+16+(legendHeight*2));
  fill(320,30,100);
  rect(legendX, legendY-2+(legendHeight*3), legendX+legendWidth, legendY+16+(legendHeight*3));

  colorMode(RGB);
  fill(0);
  textSize(12);
  text("\u3053\u306e\u5e74\u4ee3\u306e\u4eba\u306e\u6570", legendX, legendY);
  text("\u50cd\u3044\u3066\u3044\u308b\u4eba\u306e\u6570\uff08\u7537\u5973\u5408\u308f\u305b\u3066\uff09", legendX, legendY+legendHeight);
  text("\u7d50\u5a5a\u3057\u3066\u3044\u308b\u4eba\u306e\u6570\uff08\u7537\u5973\u5408\u308f\u305b\u3066\uff09", legendX, legendY+(legendHeight*2));
  text("\u3053\u306e\u5e74\u4ee3\u306e\u6bcd\u89aa\u304c\u7523\u3093\u3060\u8d64\u3061\u3083\u3093\u306e\u6570", legendX, legendY+(legendHeight*3));
}

public void drawYearLabels() {
  rectMode(CORNERS);
  noStroke();
  textAlign(CENTER,TOP);
  tabTop     = plotY2 + 10;
  tabBottom  = tabTop + 30;  

  int selectyear = PApplet.parseInt(data.getRowName(currentRow));
  for (int y = yearMin; y <= yearMax; y=y+5) {
    float x = map(y, yearMin, yearMax, plotX1, plotX2);
    
    // If the current tab, use black for the text, otherwise use dark gray
    if(y == selectyear){
      textAlign(LEFT,TOP);
//pattern 1
//      textSize(24);
//      text("\u8abf\u67fb\u5e74", plotX1+20,plotY1+85);
//      textSize(96);
//      text(y, plotX1+90,plotY1+20);
//      textSize(36);
//      text("\u5e74\u3067\u306f", plotX1+333,plotY1+73);

//pattern 2
      textSize(96);
      text(y, plotX1+20,plotY1+20);
      textSize(36);
      if(y<=2010){
        text("\u5e74\u306b\u306f", plotX1+263,plotY1+73);
      }else{
        text("\u5e74\u306b\u306f(\u4e88\u6e2c\u5024)", plotX1+263,plotY1+73);
      }
//pattern 2

      textAlign(CENTER,TOP);
      fill(255);
      rect(x-15, tabTop, x+15, tabBottom );
      fill(0);
      textSize(18);
    }else{
      fill(64);
      textSize(14);
    }
    text(y % 100, x, tabTop+5);   
    if (y % yearInterval == 0) {
      textSize(14);
      text(y, x, tabBottom);
    }
  }

  if (tabLeft == null) {
    tabLeft = new float[rowCount];
    tabRight = new float[rowCount];
  }
  for (int row = 0; row < rowCount; row++) {
    float x = map(PApplet.parseInt(data.getRowName(row)), yearMin, yearMax, plotX1, plotX2);
    tabLeft[row]  = x-15; 
    tabRight[row] = x+15;
  }
}

public void drawVolumeLabels() {
  textSize(14);
  textAlign(RIGHT,BOTTOM);
  
  fill(0);
  strokeWeight(1);

  for (float v = dataMin; v <= dataMax; v += volumeIntervalMinor) {
    if (v % volumeIntervalMinor == 0) {     // If a tick mark
      float y = map(v, dataMin, dataMax, plotY2, plotY1);  
      if (v % volumeInterval == 0) {        // If a major tick mark
        text(floor(v/10000), plotX1 - 10, y+(textAscent()/2));
        stroke(225);
        line(plotX1 - 6, y, plotX2, y);     // Draw major tick
      } else {
        stroke(240);
        line(plotX1, y, plotX2, y);   // Draw minor tick
      }
    }
  }
}


public void drawDataArea(int col) {
  beginShape();
  for (int row = 0; row < rowCount; row++) {
    if (data.isValid(row, col)) {
      float value = interpolators[row].value;
      float x = map(years[row], yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      vertex(x, y);
    }
  }
  vertex(plotX2, plotY2);
  vertex(plotX1, plotY2);
  endShape(CLOSE);
}


public void drawDataBars(int row) {
  noStroke();
  rectMode(CORNERS);
  textSize(12);
  
  //Drow Previous Year Data for Dead People.
  colorMode(RGB,256,256,256);
  for (int col = 0; col < columnCount; col++) {
    if (data.isValid(row-1, col)) {
      float value = data.getFloat(row-1, col);
      float x = map(years[row-1]-(col+1)*5, yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      fill(220);
      rect(x, y, x+barWidth, plotY2);
    }
  }

  colorMode(HSB,360,100,100);
  for (int col = 0; col < columnCount; col++) {
    if (data.isValid(row, col)) {
      float value = data.getFloat(row, col);
      float x = map(years[row]-(col+1)*5, yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      if(years[row]<=2010){
        fill(map(col,1,columnCount,30,45),map(col,1,columnCount,45,20),map(col,1,columnCount,95,95));
//        fill(map(col,1,columnCount,1,100),100,90);
      }else{
        fill(map(col,1,columnCount,30,45),map(col,1,columnCount,30,10),95);
      } 
      rect(x, y, x+barWidth, plotY2);
      
      //Min age 
      fill(map(col,1,columnCount,1,100),map(col,1,columnCount,50,30),30);
      textAlign(CENTER,TOP);
      text(col*5+"\u6b73", x+barWidth/2, y);
    }
  }
  colorMode(RGB,256,256,256);
}

public void drawMarriageDataBars(int row) {
  noStroke();
  rectMode(CORNERS);

  colorMode(HSB,360,100,100);
  for (int col = 0; col <= marriageColumnCount; col++) {
    if (row < marriageRowCount && marriageData.isValid(row, col)) {
      float value = marriageData.getFloat(row, col);
      float x = map(years[row]-(col+1)*5, yearMin, yearMax, plotX1, plotX2)+(barWidth*0.5f);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
//      fill(map(col,1,columnCount,1,100),map(col,1,columnCount,100,40),60);
//      fill(map(col,1,columnCount,1,100),80,60);
      fill(135,map(col,1,columnCount,75,55),100);
      rect(x, y, x+(barWidth*0.5f), plotY2);
      }
  }
  colorMode(RGB,256,256,256);
}

public void drawBirthDataBars(int row) {
  noStroke();
  rectMode(CORNERS);

  colorMode(HSB,360,100,100);
  for (int col = 0; col <= birthColumnCount; col++) {
    if (row < birthRowCount && birthData.isValid(row, col)) {
      float value = birthData.getFloat(row, col);
      float x = map(years[row]-(col+1)*5, yearMin, yearMax, plotX1, plotX2);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      fill(320,map(col,1,columnCount,80,60),100);
      rect(x, y, x+(barWidth*0.7f), plotY2);
      }
  }
  colorMode(RGB,256,256,256);
}

public void drawLaborDataBars(int row) {
  noStroke();
  rectMode(CORNERS);

  colorMode(HSB,360,100,100);
  for (int col = 0; col <= laborColumnCount; col++) {
    if (row < laborRowCount && laborData.isValid(row, col)) {
      float value = laborData.getFloat(row, col);
      float x = map(years[row]-(col+1)*5, yearMin, yearMax, plotX1, plotX2)+(barWidth*0.8f);
      float y = map(value, dataMin, dataMax, plotY2, plotY1);
      fill(245,map(col,1,columnCount,60,30),100);
      rect(x, y, x+(barWidth*0.2f), plotY2);
      }
  }
  colorMode(RGB,256,256,256);
}


// first line of the file should be the column headers
// first column should be the row titles
// all other values are expected to be floats
// getFloat(0, 0) returns the first data value in the upper lefthand corner
// files should be saved as "text, tab-delimited"
// empty rows are ignored
// extra whitespace is ignored


class FloatTable {
  int rowCount;
  int columnCount;
  float[][] data;
  String[] rowNames;
  String[] columnNames;
  
  
  FloatTable(String filename) {
    String[] rows = loadStrings(filename);
    
    String[] columns = split(rows[0], TAB);
    columnNames = subset(columns, 1); // upper-left corner ignored
    scrubQuotes(columnNames);
    columnCount = columnNames.length;

    rowNames = new String[rows.length-1];
    data = new float[rows.length-1][];

    // start reading at row 1, because the first row was only the column headers
    for (int i = 1; i < rows.length; i++) {
      if (trim(rows[i]).length() == 0) {
        continue; // skip empty rows
      }
      if (rows[i].startsWith("#")) {
        continue;  // skip comment lines
      }

      // split the row on the tabs
      String[] pieces = split(rows[i], TAB);
      scrubQuotes(pieces);
      
      // copy row title
      rowNames[rowCount] = pieces[0];
      // copy data into the table starting at pieces[1]
      data[rowCount] = parseFloat(subset(pieces, 1));

      // increment the number of valid rows found so far
      rowCount++;      
    }
    // resize the 'data' array as necessary
    data = (float[][]) subset(data, 0, rowCount);
  }
  
  
  public void scrubQuotes(String[] array) {
    for (int i = 0; i < array.length; i++) {
      if (array[i].length() > 2) {
        // remove quotes at start and end, if present
        if (array[i].startsWith("\"") && array[i].endsWith("\"")) {
          array[i] = array[i].substring(1, array[i].length() - 1);
        }
      }
      // make double quotes into single quotes
      array[i] = array[i].replaceAll("\"\"", "\"");
    }
  }
  
  
  public int getRowCount() {
    return rowCount;
  }
  
  
  public String getRowName(int rowIndex) {
    return rowNames[rowIndex];
  }
  
  
  public String[] getRowNames() {
    return rowNames;
  }

  
  // Find a row by its name, returns -1 if no row found. 
  // This will return the index of the first row with this name.
  // A more efficient version of this function would put row names
  // into a Hashtable (or HashMap) that would map to an integer for the row.
  public int getRowIndex(String name) {
    for (int i = 0; i < rowCount; i++) {
      if (rowNames[i].equals(name)) {
        return i;
      }
    }
    //println("No row named '" + name + "' was found");
    return -1;
  }
  
  
  // technically, this only returns the number of columns 
  // in the very first row (which will be most accurate)
  public int getColumnCount() {
    return columnCount;
  }
  
  
  public String getColumnName(int colIndex) {
    return columnNames[colIndex];
  }
  
  
  public String[] getColumnNames() {
    return columnNames;
  }


  public float getFloat(int rowIndex, int col) {
    // Remove the 'training wheels' section for greater efficiency
    // It's included here to provide more useful error messages
    
    // begin training wheels
    if ((rowIndex < 0) || (rowIndex >= data.length)) {
      throw new RuntimeException("There is no row " + rowIndex);
    }
    if ((col < 0) || (col >= data[rowIndex].length)) {
      throw new RuntimeException("Row " + rowIndex + " does not have a column " + col);
    }
    // end training wheels
    
    return data[rowIndex][col];
  }
  
  
  public boolean isValid(int row, int col) {
    if (row < 0) return false;
    if (row > rowCount) return false;
    //if (col >= columnCount) return false;
    if (col >= data[row].length) return false;
    if (col < 0) return false;
    return !Float.isNaN(data[row][col]);
  }


  public float getColumnMin(int col) {
    float m = Float.MAX_VALUE;
    for (int row = 0; row < rowCount; row++) {
      if (isValid(row, col)) {
        if (data[row][col] < m) {
          m = data[row][col];
        }
      }
    }
    return m;
  }


  public float getColumnMax(int col) {
    float m = -Float.MAX_VALUE;
    for (int row = 0; row < rowCount; row++) {
      if (isValid(row, col)) {
        if (data[row][col] > m) {
          m = data[row][col];
        }
      }
    }
    return m;
  }

  
  public float getRowMin(int row) {
    float m = Float.MAX_VALUE;
    for (int col = 0; col < columnCount; col++) {
      if (isValid(row, col)) {
        if (data[row][col] < m) {
          m = data[row][col];
        }
      }
    }
    return m;
  } 


  public float getRowMax(int row) {
    float m = -Float.MAX_VALUE;
    for (int col = 0; col < columnCount; col++) {
      if (isValid(row, col)) {
        if (data[row][col] > m) {
          m = data[row][col];
        }
      }
    }
    return m;
  }


  public float getTableMin() {
    float m = Float.MAX_VALUE;
    for (int row = 0; row < rowCount; row++) {
      for (int col = 0; col < columnCount; col++) {
        if (isValid(row, col)) {
          if (data[row][col] < m) {
            m = data[row][col];
          }
        }
      }
    }
    return m;
  }


  public float getTableMax() {
    float m = -Float.MAX_VALUE;
    for (int row = 0; row < rowCount; row++) {
      for (int col = 0; col < columnCount; col++) {
        if (isValid(row, col)) {
          if (data[row][col] > m) {
            m = data[row][col];
          }
        }
      }
    }
    return m;
  }
}
class Integrator {

  final float DAMPING = 0.5f;
  final float ATTRACTION = 0.2f;

  float value;
  float vel;
  float accel;
  float force;
  float mass = 1;

  float damping = DAMPING;
  float attraction = ATTRACTION;
  boolean targeting;
  float target;


  Integrator() { }


  Integrator(float value) {
    this.value = value;
  }


  Integrator(float value, float damping, float attraction) {
    this.value = value;
    this.damping = damping;
    this.attraction = attraction;
  }


  public void set(float v) {
    value = v;
  }


  public void update() {
    if (targeting) {
      force += attraction * (target - value);      
    }

    accel = force / mass;
    vel = (vel + accel) * damping;
    value += vel;

    force = 0;
  }


  public void target(float t) {
    targeting = true;
    target = t;
  }


  public void noTarget() {
    targeting = false;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "wave_of_jp_population" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
